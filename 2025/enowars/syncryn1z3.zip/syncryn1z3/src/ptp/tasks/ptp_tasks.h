#pragma once

struct ptp_state;

int ptp_handle_message(struct ptp_state *state);
