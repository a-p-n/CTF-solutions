# Hacktheon 2025

## TAR

### How to
```
./build.sh
./run.sh
nc localhost 32496
```