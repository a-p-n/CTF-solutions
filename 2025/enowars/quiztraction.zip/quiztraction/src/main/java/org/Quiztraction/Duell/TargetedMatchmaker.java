package org.Quiztraction.Duell;

import org.Quiztraction.Connection.Connection;
import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;
import org.Quiztraction.Main;
import org.Quiztraction.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class TargetedMatchmaker {
    static TargetedMatchmaker instance;
    static DatabaseWrapper database;

    public static TargetedMatchmaker getInstance() throws SQLException {
        if (instance == null) instance = new TargetedMatchmaker();
        return instance;
    }

    private TargetedMatchmaker() throws SQLException {
        database = DatabaseWrapper.getInstance();
        Thread targetedMatchmakerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        String sql = "SELECT * FROM openTargetedMatches;";
                        PreparedStatement stmt = database.prepareSanitizeQuery(sql);
                        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                            while (resultSet.next()) {
                                String timeZone = resultSet.getString("user_timezone");
                                Calendar userTimeCalendar = Calendar.getInstance(java.util.TimeZone.getTimeZone(timeZone));
                                long userTime = userTimeCalendar.getTime().getTime();
                                long autoAcceptTime = resultSet.getLong("automatic_accept_time");
                                if (userTime > autoAcceptTime) {
                                    int id = resultSet.getInt("id");
                                    String challenger = resultSet.getString("challenger");
                                    String target_player = resultSet.getString("target_player");
                                    startNewTargetedMatch(id, challenger, target_player);
                                    sql = "DELETE FROM openTargetedMatches WHERE id = ?;";
                                    database.executeSanitizeUpdateQuery(sql, id);
                                }
                            }
                        }

                        TimeUnit.SECONDS.sleep(1);
                    } catch (InterruptedException | SQLException e) {
                        try {
                            System.err.println("Restarting TargetedMatchmaker.");
                            instance = new TargetedMatchmaker();
                            Main.updateTargetedMatchmaker();
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        targetedMatchmakerThread.start();
    }

    private void startNewTargetedMatch(int id, String challenger, String target_player) throws SQLException {
        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();
        String sql = "INSERT INTO runningTargetedMatches (id, challenger, target_player, currentQuestionID, challenger_score, target_player_score, challenger_answer_correct, target_player_answer_correct, round, creation_time) VALUES (?, ?, ?, null, '0', '0', null, null, 1, ?);";
        database.executeSanitizeUpdateQuery(sql, id, challenger, target_player, currentTime);
    }
}
