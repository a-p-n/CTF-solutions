package org.Quiztraction;

import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Tag {
    int id;
    String name;
    String creator;
    static DatabaseWrapper database;

    public Tag(int tagID) throws SQLException {
        if (database == null) database = DatabaseWrapper.getInstance();
        String sql = "SELECT * FROM tags WHERE id = ?";
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, tagID);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            if (resultSet.next()) {
                this.id = resultSet.getInt("id");
                this.name = resultSet.getString("name");
                this.creator = resultSet.getString("creator");
            }
        }

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCreator() {
        return creator;
    }
}
