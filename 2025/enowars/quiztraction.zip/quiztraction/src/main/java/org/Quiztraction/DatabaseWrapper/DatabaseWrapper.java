package org.Quiztraction.DatabaseWrapper;

import org.Quiztraction.Main;
import org.Quiztraction.Question;
import org.Quiztraction.Tag;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class DatabaseWrapper {
    final String url = "jdbc:sqlite:./data/database.db";
    java.sql.Connection connection;
    private static DatabaseWrapper instance;

    private DatabaseWrapper() {
        try {
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static DatabaseWrapper getInstance() throws SQLException {
        if (instance == null) {
            instance = new DatabaseWrapper();
            instance.init();
        }
        return instance;
    }

    private void init() throws SQLException {
        // creation_time is only for cleanup, there is definitely not a vulnerability :)
        String sql = "CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT, timeZone TEXT, status TEXT, lastLogin BIGINT);";
        executeSanitizeUpdateQuery(sql);
        sql = "CREATE TABLE IF NOT EXISTS deactivatedUsers (username TEXT PRIMARY KEY, password TEXT, timeZone TEXT, status TEXT, lastLogin BIGINT);";
        executeSanitizeUpdateQuery(sql);
        sql = "CREATE TABLE IF NOT EXISTS tags (id INTEGER PRIMARY KEY, name TEXT, creator TEXT, creation_time BIGINT)";
        executeSanitizeUpdateQuery(sql);
        sql = "CREATE TABLE IF NOT EXISTS questions (id INTEGER PRIMARY KEY, name TEXT, answer0 TEXT, answer1 TEXT, answer2 TEXT, answer3 TEXT, correct_answer INT, tag_id INT, creator TEXT, public BOOLEAN, creation_time BIGINT);";
        executeSanitizeUpdateQuery(sql);
        initQuestions();
        sql = "CREATE TABLE IF NOT EXISTS openTargetedMatches (id INTEGER PRIMARY KEY AUTOINCREMENT, challenger TEXT, target_player TEXT, automatic_accept_time BIGINT, user_timezone TEXT, creation_time BIGINT);";
        executeSanitizeUpdateQuery(sql);
        sql = "CREATE TABLE IF NOT EXISTS runningTargetedMatches (id INTEGER PRIMARY KEY, challenger TEXT, target_player TEXT, currentQuestionID INT, challenger_score INT, target_player_score INT, challenger_answer_correct BOOLEAN, target_player_answer_correct BOOLEAN, round INT, creation_time BIGINT);";
        executeSanitizeUpdateQuery(sql);
        sql = "CREATE TABLE IF NOT EXISTS finishedTargetedMatches (id INTEGER PRIMARY KEY, challenger TEXT, target_player TEXT, challenger_score INT, target_player_score INT, creation_time BIGINT);";
        executeSanitizeUpdateQuery(sql);
    }

    public PreparedStatement prepareSanitizeQuery(String query, Object... args) throws SQLException {
        PreparedStatement stmt;
        stmt = connection.prepareStatement(query);
        int i = 1;
        for (Object arg : args) {
            i = handleClasses(stmt, i, arg);
        }
        //System.out.println(stmt.toString());
        return stmt;
    }

    public int executeSanitizeUpdateQuery(String query, Object... args) throws SQLException {
        PreparedStatement stmt;
        stmt = connection.prepareStatement(query);
        int i = 1;
        for (Object arg : args) {
            if (arg == null) {
                stmt.setNull(i, Types.VARCHAR);
                i++;
                continue;
            }
            i = handleClasses(stmt, i, arg);
        }
        //System.out.println(stmt.toString());
        int value = stmt.executeUpdate();
        stmt.close();
        return value;
    }

    private int handleClasses(PreparedStatement stmt, int i, Object arg) throws SQLException {
        switch (arg.getClass().getSimpleName()) {
            case "String":
                stmt.setString(i, (String) arg);
                break;
            case "Integer":
                stmt.setInt(i, (Integer) arg);
                break;
            case "Long":
                stmt.setLong(i, (Long) arg);
                break;
            default:
                System.out.println("Unknown argument type: " + arg.getClass().getSimpleName());
                break;
        }
        i++;
        return i;
    }

    private void initQuestions() throws SQLException {
        String sql = "SELECT MAX(id) FROM questions;";
        int current_highest_id;
        PreparedStatement stmt = prepareSanitizeQuery(sql);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            current_highest_id = resultSet.getInt(1);
        }

        if (current_highest_id > 0) {
            System.err.println("Found questions highest id: " + current_highest_id);
            System.err.println("Skipping import of more questions.");
            return;
        }

        String text = "";

        try(final InputStream stream = Main.class.getResourceAsStream("/questions")) {
            if (stream != null) {
                text = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
            } else {
                System.err.println("failed to read text");
            }
        }
        catch (Exception e)
        {
            System.err.println("Cant import questions. Adding dummy questions.");
            System.err.println(e.getMessage());
            addQuestion("Is it possible to use more than 2 questions?", "Yes", "Maybe", "Apparently not", "Next time", 2, "Fallback Question", "", true);
            addQuestion("Will you look at the log to find the reason why there are only 2 questions?", "No, i am to lazy", "No, because i like the two questions", "No, because it says: \"Skipping import of more questions.\"", "Yes, and i will look for \"Cant import questions. Adding dummy questions.\"", 3, "Fallback question", "", true);
        }

        String[] entries = text.split(",\n");

        for (String entry : entries) {
            entry = entry.trim();
            if (entry.startsWith("{") && entry.endsWith("}")) {
                entry = entry.substring(1, entry.length() - 1);
                String[] parts = entry.split(";");
                if (parts.length == 9) {
                    String questionText = parts[0].trim();
                    String answer0 = parts[1].trim();
                    String answer1 = parts[2].trim();
                    String answer2 = parts[3].trim();
                    String answer3 = parts[4].trim();
                    int correctIndex = Integer.parseInt(parts[5].trim());
                    String tag = parts[6].trim();
                    String creator = parts[7].trim();
                    boolean poblic = Boolean.parseBoolean(parts[8].trim());

                    addQuestion(questionText, answer0, answer1, answer2, answer3, correctIndex, tag, creator, poblic);
                }
                else {
                    System.err.println("Skipped entry: " + entry);
                }
            }
            else {
                System.err.println("Skipped entry: " + entry);
            }
        }
    }

    public boolean validCredentials(String username, String password) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? AND password = ?;";
        try {
            int count;
            PreparedStatement stmt = prepareSanitizeQuery(sql, username, password);
            try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                count = resultSet.getInt(1);
            }
            return count == 1;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean existsUser(String username) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?;";
        try {
            int count;
            PreparedStatement stmt = prepareSanitizeQuery(sql, username);
            try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                count = resultSet.getInt(1);
            }
            return count >= 1;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int addUser(String username, String password) throws SQLException {
        if (existsUser(username)) {
            return -1;
        }
        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();
        String sql = "INSERT INTO users (username, password, timeZone, lastLogin) VALUES (?, ?, 'Europe/Berlin', ?)";
        return executeSanitizeUpdateQuery(sql, username, password, currentTime);
    }

    public void addQuestion(String question, String answer0, String answer1, String answer2, String answer3, int correct_answer, String tag, String creator, boolean poblic) throws SQLException {
        int tagId = getTagId(tag, creator);

        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();

        String sql = "INSERT INTO questions (name, answer0, answer1, answer2, answer3, correct_answer, tag_id, creator, public, creation_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, " + (poblic ? "true" : "false") + ", ?);";
        executeSanitizeUpdateQuery(sql, question, answer0, answer1, answer2, answer3, correct_answer, tagId, creator, currentTime);
    }

    public void addQuestionWithID(int id, String question, String answer0, String answer1, String answer2, String answer3, int correct_answer, String tag, String creator, boolean poblic) throws SQLException {
        int tagId = getTagId(tag, creator);

        String sql = "SELECT * FROM questions WHERE id = ?";
        PreparedStatement stmt = prepareSanitizeQuery(sql, id);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            if (resultSet.next()) {return;}
        }

        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();

        sql = "INSERT INTO questions (name, answer0, answer1, answer2, answer3, correct_answer, tag_id, creator, public, creation_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, " + (poblic ? "true" : "false") + ", ?);";
        executeSanitizeUpdateQuery(sql, question.trim(), answer0.trim(), answer1.trim(), answer2.trim(), answer3.trim(), correct_answer, tagId, creator, currentTime);
    }

    public int getTagId(String tag, String creator) throws SQLException {
        String sql = "SELECT id FROM tags WHERE name = ?;";
        int id;
        PreparedStatement stmt = prepareSanitizeQuery(sql, tag);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            if (!resultSet.next()) {
                id = addTag(tag, creator);
            }
            else {
                id = resultSet.getInt("id");
            }
        }
        return id;
    }

    public String getTagName(int id) throws SQLException {
        String sql = "SELECT name FROM tags WHERE id = ?;";
        PreparedStatement stmt = prepareSanitizeQuery(sql, id);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            return resultSet.getString("name");
        }
    }

    public int addTag(String tag, String creator) throws SQLException {
        String sql = "SELECT * FROM tags WHERE name = ?;";
        PreparedStatement stmt = prepareSanitizeQuery(sql, tag);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            if (resultSet.next()) {return -1;}
        }

        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();
        sql = "INSERT INTO tags (name, creator, creation_time) VALUES (?, ?, ?);";
        executeSanitizeUpdateQuery(sql, tag, creator, currentTime);

        sql = "SELECT id FROM tags WHERE name = ?;";
        PreparedStatement stmtId = prepareSanitizeQuery(sql, tag);
        int tag_id;
        try (stmtId; ResultSet resultSet = stmtId.executeQuery()) {
            tag_id = resultSet.getInt("id");
        }
        return tag_id;
    }

    public void addOpenTargetedMatch(String challenger, String targetedPlayer, long automaticAcceptTime, String userTimeZone) throws SQLException {
        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();
        String sql = "INSERT INTO openTargetedMatches (challenger, target_player, automatic_accept_time, user_timezone, creation_time) VALUES (?, ?, ?, ?, ?);";
        executeSanitizeUpdateQuery(sql, challenger, targetedPlayer, automaticAcceptTime, userTimeZone, currentTime);
    }

    public Question getRandomQuestion(String username1, String username2) throws SQLException {
        String sql = "SELECT * FROM questions WHERE public IS 1 OR (creator IS ? OR creator IS ?) ORDER BY RANDOM() LIMIT 1;";
        int questionID;
        String questionString;
        String answer0String;
        String answer1String;
        String answer2String;
        String answer3String;
        int correct_answer;
        PreparedStatement stmt = prepareSanitizeQuery(sql, username1, username2);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            questionID = resultSet.getInt("id");
            questionString = resultSet.getString("name");
            answer0String = resultSet.getString("answer0");
            answer1String = resultSet.getString("answer1");
            answer2String = resultSet.getString("answer2");
            answer3String = resultSet.getString("answer3");
            correct_answer = resultSet.getInt("correct_answer");
        }
        Question question = new Question(questionID);
        return question;
    }

    public String getUserStatus(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?;";
        String status;
        PreparedStatement stmt = prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            status = resultSet.getString("status");
        }
        return status;
    }

    public TimeZone getUserTimeZone(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?;";
        String timeZone;
        PreparedStatement stmt = prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            timeZone = resultSet.getString("timeZone");
        }
        return TimeZone.getTimeZone(timeZone);
    }

    public String getUserTimeZoneString(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?;";
        String timeZone;
        PreparedStatement stmt = prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            timeZone = resultSet.getString("timeZone");
        }
        return timeZone;
    }

    public long getUserLastLoginTime(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?;";
        long time;
        PreparedStatement stmt = prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            time = resultSet.getLong("lastLogin");
        }
        return time;
    }

    public Tag[] getAllTagsFromuser(String username) throws SQLException {
        String sql = "SELECT * FROM tags WHERE creator = ?;";
        List<Tag> tags = new ArrayList<>();
        PreparedStatement stmt = prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                Tag tag = new Tag(resultSet.getInt("id"));
                tags.add(tag);
            }
        }
        return tags.toArray(new Tag[tags.size()]);
    }

    public Question[] getAllQuestionsFromUser(String username) throws SQLException {
        String sql = "SELECT * FROM questions WHERE creator = ?;";
        List<Question> questions = new ArrayList<>();
        PreparedStatement stmt = prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                Question question = new Question(resultSet.getInt("id"));
                questions.add(question);
            }
        }
        return questions.toArray(new Question[questions.size()]);
    }

    public void deleteAllQuestionsFromUser(String username) throws SQLException {
        String sql = "DELETE FROM questions WHERE creator = ?;";
        executeSanitizeUpdateQuery(sql, username);
    }

    public void deleteAllUnusedTagsFromUser(String username) throws SQLException {
        String sql = "DELETE FROM tags WHERE creator = ? AND id NOT IN (SELECT DISTINCT tag_id FROM questions WHERE tag_id IS NOT NULL);";
        executeSanitizeUpdateQuery(sql, username);
    }
}
