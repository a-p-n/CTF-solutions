package org.Quiztraction.Duell;

import org.Quiztraction.Connection.Connection;
import org.Quiztraction.Main;
import org.Quiztraction.User;

import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.random.RandomGenerator;

public class Matchmaker {
    private static Matchmaker instance;
    LinkedList<User> usersSearchingMatch = new LinkedList<>();
    RandomGenerator rand = new Random();

    public static Matchmaker getInstance() {
        if (instance == null) instance = new Matchmaker();
        return instance;
    }

    private Matchmaker() {
        Thread matchmakerThread = new Thread(new Runnable() {
            @Override
            public void run() {
                int random;
                while (true) {
                    System.out.println("players in queue: " + usersSearchingMatch.size());
                    while (usersSearchingMatch.size() >= 2) {
                        random = ThreadLocalRandom.current().nextInt(0, usersSearchingMatch.size());
                        User player1 = usersSearchingMatch.remove(random);
                        random = ThreadLocalRandom.current().nextInt(0, usersSearchingMatch.size());
                        User player2 = usersSearchingMatch.remove(random);
                        Match match = new Match(player1, player2);
                        player1.connection.setCurrentMatch(match);
                        player2.connection.setCurrentMatch(match);
                        player1.connection.setSignal(Connection.Signal.FOUND_MATCH);
                        player2.connection.setSignal(Connection.Signal.FOUND_MATCH);
                        match.start();
                    }
                    try {
                        TimeUnit.SECONDS.sleep(10);
                    } catch (InterruptedException e) {
                        System.err.println("Restarting Matchmaker.");
                        instance = new Matchmaker();
                        Main.updateMatchmaker();
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        matchmakerThread.start();
    }

    public void addUserToQueue(User user) {
        usersSearchingMatch.add(user);
        user.connection.setSignal(Connection.Signal.WAIT_FOR_MATCH);
    }

    public void removeUserFromQueue(User user) {
        usersSearchingMatch.remove(user);
        user.connection.setSignal(Connection.Signal.EMPTY_SIGNAL);
    }

    public int getUserCount() {
        return usersSearchingMatch.size();
    }
}
