package org.Quiztraction.Connection;

import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;
import org.Quiztraction.Duell.Match;
import org.Quiztraction.Duell.Matchmaker;
import org.Quiztraction.Main;
import org.Quiztraction.Question;
import org.Quiztraction.Tag;
import org.Quiztraction.User;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class Connection implements Runnable {
    Socket socket;
    OutputStream out;
    InputStream in;
    Scanner scanner;
    User user = null;
    Signal signal = Signal.EMPTY_SIGNAL;
    Match currentMatch = null;
    boolean currentAnswerCorrect;


    public enum Signal {
        WAIT_FOR_MATCH,
        FOUND_MATCH,
        NEW_QUESTION,
        EMPTY_SIGNAL,
        ANSWERED_QUESTION,
        GAME_WON,
        GAME_LOST,
        GAME_DRAW,
        GAME_OVER,
    }

    DatabaseWrapper database;

    @Override
    public void run() {
        try {
            printWelcomeScreen();
            userNotLoggedIn();
        } catch (IOException | InterruptedException | SQLException e) {
            if (e instanceof SocketException) {
                try {
                    socket.close();
                    in.close();
                    out.close();
                    scanner.close();
                } catch (IOException e1) {
                    throw new RuntimeException(e1);
                }
            }
            else {
                throw new RuntimeException(e);
            }
        }
    }

    public Connection(Socket socket) throws IOException, SQLException {
        this.socket = socket;
        this.out = socket.getOutputStream();
        this.in = socket.getInputStream();
        scanner = new Scanner(this.in);
        database = DatabaseWrapper.getInstance();


    }

    public void setSignal(Signal signal) {
        this.signal = signal;
    }

    public Signal getSignal() {
        return signal;
    }

    private void userNotLoggedIn() throws IOException, InterruptedException, SQLException {
        while (user == null) {
            String action = loggedOutActions();
            switch(action) {
                case "0":
                    registerUser();
                    break;
                case "1":
                    loginUser();
                    break;
            }
        }
        userLoggedIn();
    }

    private void userLoggedIn() throws IOException, InterruptedException, SQLException {
        while (user != null) {
            String action = loggedInActions();
            switch(action) {
                case "0":
                    startNewMatch();
                    break;
                case "1":
                    openTargetedMatch();
                    break;
                case "2":
                    openManageQuestionsMenu();
                    break;
                case "3":
                    openSettings();
                    break;
                case "4":
                    user = null;
                    break;
            }
        }
        userNotLoggedIn();
    }

    private void openSettings() throws IOException, SQLException {
        String action = settingsActions();
        switch(action) {
            case "0":
                setStatus();
                break;
            case "1":
                setTimeZone();
                break;
            case "2":
                // go back
                break;
        }
    }

    private void setStatus() throws IOException, SQLException {
        String current_status = database.getUserStatus(this.user.getName());
        current_status = (current_status == null) ? "" : current_status;
        pressEnterToContinue("Current status: " + current_status);
        out.write("Your next Status: ".getBytes());
        String next_status = getInput();
        removeLines(1);
        String sql = "UPDATE users SET status = ? WHERE username = ?;";
        database.executeSanitizeUpdateQuery(sql, next_status, user.getName());
        pressEnterToContinue("Status updated");
    }

    private void setTimeZone() throws IOException, SQLException {
        String current_timezone = database.getUserTimeZoneString(this.user.getName());
        current_timezone = (current_timezone == null) ? "" : current_timezone;
        pressEnterToContinue("Current timezone: " + current_timezone);
        out.write("Your next TimeZone: ".getBytes());
        String timeZone = getInput();
        removeLines(1);
        String sql = "UPDATE users SET timeZone = ? WHERE username = ?;";
        database.executeSanitizeUpdateQuery(sql, timeZone, user.getName());
        user.setTimeZone(TimeZone.getTimeZone(timeZone));
        pressEnterToContinue("TimeZone updated");
    }

    private void setLastLoginTime() throws SQLException {
        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();
        String sql = "UPDATE users SET lastLogin = ? WHERE username = ?;";
        database.executeSanitizeUpdateQuery(sql, currentTime, user.getName());
        user.setLastLoginTime(currentTime);
    }

    private void openManageQuestionsMenu() throws IOException, InterruptedException, SQLException {
        String action = manageQuestionsActions();
        switch(action) {
            case "0":
                openAddMenu();
                break;
            case "1":
                openImportMenu();
                break;
            case "2":
                openExportMenu();
                break;
            case "3":
                openDeleteMenu();
                break;
            case "4":
                listYourTagsAndQuestions();
                break;
            case "5":
                break;
        }
    }

    private String manageQuestionsActions() throws IOException {
        printManageQuestionsScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2") ||
                Objects.equals(input, "3") ||
                Objects.equals(input, "4") ||
                Objects.equals(input, "5"))) {
            //System.out.println(input);
            removeLines(8);
            printManageQuestionsScreen();

            input = getInput();
        }
        removeLines(8);
        return input;
    }

    private void openAddMenu() throws IOException, InterruptedException, SQLException {
        String action = addActions();
        switch(action) {
            case "0":
                openAddTag();
                break;
            case "1":
                openAddQuestion();
                break;
            case "2":
                break;
        }
    }

    private String addActions() throws IOException {
        printAddScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2"))) {
            //System.out.println(input);
            removeLines(6);
            printAddScreen();

            input = getInput();
        }
        removeLines(6);
        return input;
    }

    private void openExportMenu() throws IOException, SQLException {
        String action = exportActions();
        switch(action) {
            case "0":
                exportTags();
                break;
            case "1":
                exportQuestions();
                break;
            case "2":
                exportTagsAndQuestions();
                break;
            case "3":
                break;
        }
    }

    private String exportActions() throws IOException {
        printExportScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2") ||
                Objects.equals(input, "3"))) {
            //System.out.println(input);
            removeLines(6);
            printExportScreen();

            input = getInput();
        }
        removeLines(6);
        return input;
    }

    private void openImportMenu() throws IOException, SQLException {
        String action = importActions();
        switch(action) {
            case "0":
                importTags();
                break;
            case "1":
                importQuestions();
                break;
            case "2":
                importTagsAndQuestions();
                break;
            case "3":
                break;
        }
    }

    private String importActions() throws IOException {
        printImportScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2") ||
                Objects.equals(input, "3"))) {
            //System.out.println(input);
            removeLines(6);
            printImportScreen();

            input = getInput();
        }
        removeLines(6);
        return input;
    }

    private void openDeleteMenu() throws IOException, SQLException {
        String action = deleteActions();
        switch(action) {
            case "0":
                deleteAllUnusedTags();
                break;
            case "1":
                deleteAllQuestions();
                break;
            case "2":
                break;
        }
    }

    private String deleteActions() throws IOException {
        printDeleteScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2"))) {
            //System.out.println(input);
            removeLines(5);
            printDeleteScreen();

            input = getInput();
        }
        removeLines(5);
        return input;
    }

    public void deleteAllUnusedTags() throws IOException, SQLException {
        Random rand = new Random();
        while (true) {
            out.write("Are you sure you want to delete all your questions?\n".getBytes());

            int randomNumber = rand.nextInt(100, 999);

            String randomString = String.valueOf(randomNumber);
            // System.out.println("hello suraj it is here: ", randomString);

            out.write(("Please enter \"" + randomString + "\" to proceed (or leave empty to return): ").getBytes());
            String input = getInput();

            if (input == null) {
                return;
            }

            if (input.isEmpty()) {
                pressEnterToContinue("Tag deletion aborted");
                removeLines(2);
                return;
            }

            if (input.equals(randomString)) {
                pressEnterToContinue("Continue if you want to delete all your unused tags, else quit the program.");
                database.deleteAllUnusedTagsFromUser(this.user.getName());
                pressEnterToContinue("Unused tags deleted.");
                removeLines(2);
                return;
            }
            else {
                pressEnterToContinue("Wrong confirmation message.");
                removeLines(2);
            }
        }
    }

    public void deleteAllQuestions() throws IOException, SQLException {
        while (true) {
            out.write("Are you sure you want to delete all your questions?\n".getBytes());
            String confirmation = """
                    Yes i really want to delete all my questions and this action can only be undone with a backup. \
                    But even then it could be, that the most recent questions can not be imported automatically, \
                    because the question ID is already in use again (and allowing the import with another question ID \
                    could lead to duplicate questions (and nobody wants that)). I proceed because I am sure \
                    that this is what I want to do. And that I acknowledge that there is no server-side backup of \
                    the questions and that they could be lost forever if I decide to proceed.""";

            StringBuilder sb = new StringBuilder(confirmation);
            Random random = new Random();

            for (int i = 0; i < 50; i++) {
                int index = random.nextInt(sb.length() + 1);
                char charToInsert = '\u200B';
                sb.insert(index, charToInsert);
            }

            String confirmation2 = sb.toString();

            out.write(("Please enter \"" + confirmation2 + "\" to proceed (or type \"return\" to return): ").getBytes());
            String input = getInput();

            if (input == null) {
                return;
            }

            if (input.equals("return")) {
                out.write("\n\n".getBytes());
                pressEnterToContinue("Question deletion aborted");
                clearScreen();
                printWelcomeScreen();
                return;
            }

            if (input.contains("\u200B")) {
                pressEnterToContinue("\n\nTo make sure you understand what you are doing, please input the text by hand and don't just copy paste it. :)");
                clearScreen();
                printWelcomeScreen();
            }
            else {
                if (input.equals(confirmation)) {
                    pressEnterToContinue("Continue if you want to delete all your questions, else quit the program.");
                    database.deleteAllQuestionsFromUser(this.user.getName());
                    pressEnterToContinue("Questions deleted.");
                    clearScreen();
                    printWelcomeScreen();
                    return;
                }
                else {
                    pressEnterToContinue("Wrong confirmation message.");
                    clearScreen();
                    printWelcomeScreen();
                }
            }
        }
    }

    private void openAddTag() throws IOException, SQLException {
        out.write("Add Tag (leave a field empty to cancel creation)\n".getBytes());
        out.write("Tag name: ".getBytes());
        String tag = getInput();
        if (tag.isEmpty()) {
            removeLines(2);
            return;
        }
        int result = database.addTag(tag, this.user.getName());

        if (result == -1) {
            pressEnterToContinue("Tag already exists");
            removeLines(2);
        }
        else {
            StringBuilder message = new StringBuilder();
            message.append("Tag ");
            String numberStr = Long.toString(result);
            int length = numberStr.length();
            message.append("\u200B");
            for (int i = 0; i < length; i++) {
                char digitChar = numberStr.charAt(length - 1 - i);
                int digit = Character.getNumericValue(digitChar);
                message.append("\u200C".repeat(digit + 1));
                message.append("\u200B");
            }
            message.append("added");
            pressEnterToContinue(message.toString());
            removeLines(2);
        }
    }

    private void openAddQuestion() throws IOException, SQLException {
        out.write("Add Question (leave a field empty to cancel creation)\n".getBytes());
        out.write("Question: ".getBytes());
        String question = getInput();
        if (question.isEmpty()) {
            removeLines(2);
            return;
        }
        out.write("Answer A: ".getBytes());
        String answer0 = getInput();
        if (answer0.isEmpty()) {
            removeLines(3);
            return;
        }
        out.write("Answer B: ".getBytes());
        String answer1 = getInput();
        if (answer1.isEmpty()) {
            removeLines(4);
            return;
        }
        out.write("Answer C: ".getBytes());
        String answer2 = getInput();
        if (answer2.isEmpty()) {
            removeLines(5);
            return;
        }
        out.write("Answer D: ".getBytes());
        String answer3 = getInput();
        if (answer3.isEmpty()) {
            removeLines(6);
            return;
        }

        char correctAnswerChar = 'Z';
        while (true) {
            out.write("What is the answer of the question (A/B/C/D)? ".getBytes());
            String correctAnswer = getInput();
            if (correctAnswer.isEmpty()) {
                removeLines(7);
                return;
            }

            correctAnswerChar = correctAnswer.charAt(0);
            if (correctAnswerChar >= 'A' && correctAnswerChar <= 'D') {
                break;
            }
            else {
                removeLines(1);
            }
        }

        if (correctAnswerChar == 'Z') {
            pressEnterToContinue("Something went wrong.");
            return;
        }

        int correctAnswer = correctAnswerChar - 65;

        out.write("Tag of the question: ".getBytes());
        String tag = getInput();
        if (tag.isEmpty()) {
            removeLines(8);
            return;
        }

        boolean poblic;

        poblicQuestion:
        while (true) {
            out.write("Should the question be public (else it can only be played in private matches)? [Y/N]: ".getBytes());
            String poblicString = getInput();
            switch (poblicString) {
                case "":
                    removeLines(9);
                    return;
                case "Y":
                case "y":
                    poblic = true;
                    break poblicQuestion;
                case "N":
                case "n":
                    poblic = false;
                    break poblicQuestion;
                default:
                    removeLines(1);
                    break;
            }
        }

        database.addQuestion(question, answer0, answer1, answer2, answer3, correctAnswer, tag, user.getName(), poblic);
        pressEnterToContinue("Question added");
        removeLines(9);
    }

    private void exportTags() throws IOException, SQLException {
        out.write("Export tags\n\n\n".getBytes());
        Tag[] tags = database.getAllTagsFromuser(this.user.getName());
        JSONArray jsonTagsArray = new JSONArray(tags);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("tags", jsonTagsArray);
        String base = Base64.getEncoder().encodeToString(jsonObject.toString().getBytes());
        out.write(base.getBytes());
        out.write("\n\n\n".getBytes());

        pressEnterToContinue("Please save the string before continuing");

        clearScreen();
        printWelcomeScreen();
    }

    private void exportQuestions() throws IOException, SQLException {
        out.write("Export questions\n\n\n".getBytes());
        Question[] questions = database.getAllQuestionsFromUser(this.user.getName());
        JSONArray jsonQuestionsArray = new JSONArray(questions);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("questions", jsonQuestionsArray);
        String base = Base64.getEncoder().encodeToString(jsonObject.toString().getBytes());
        out.write(base.getBytes());
        out.write("\n\n\n".getBytes());

        pressEnterToContinue("Please save the string before continuing.");

        clearScreen();
        printWelcomeScreen();
    }

    private void exportTagsAndQuestions() throws IOException, SQLException {
        out.write("Export tags and questions\n\n\n".getBytes());

        JSONObject jsonObject = new JSONObject();

        Tag[] tags = database.getAllTagsFromuser(this.user.getName());
        JSONArray jsonTagsArray = new JSONArray(tags);
        jsonObject.put("tags", jsonTagsArray);

        Question[] questions = database.getAllQuestionsFromUser(this.user.getName());
        JSONArray jsonQuestionsArray = new JSONArray(questions);
        jsonObject.put("questions", jsonQuestionsArray);

        String base = Base64.getEncoder().encodeToString(jsonObject.toString().getBytes());
        out.write(base.getBytes());
        out.write("\n\n\n".getBytes());

        pressEnterToContinue("Please save the string before continuing.");

        clearScreen();
        printWelcomeScreen();
    }

    //TODO refactor importTags(), importQuestions() and importTagsAndQuestions()
    private void importTags() throws IOException, SQLException {
        out.write("Please paste Tags data\n\n\n".getBytes());
        String base = getInput();
        String input = new String(Base64.getDecoder().decode(base.getBytes()));
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(input);
        } catch (JSONException e) {
            pressEnterToContinue("invalid data");
            clearScreen();
            printWelcomeScreen();
            return;
        }

        String key = jsonObject.keys().next();
        JSONArray tags = jsonObject.getJSONArray(key);

        for (int i = 0; i < tags.length(); i++) {
            JSONObject tag = tags.getJSONObject(i);

            int id;
            String name;

            try {
                id = tag.getInt("id");
                name = tag.getString("name");
            } catch (JSONException e) {
                pressEnterToContinue("invalid data");
                clearScreen();
                printWelcomeScreen();
                return;
            }
            PreparedStatement stmt = getQuestionOrTag(key, id);
            try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    String creator = resultSet.getString("creator");
                    if (creator.equals(this.user.getName())) {
                        out.write(("\n\nTag \"" + name.replace('\n', ' ') + "\" already exists.\n").getBytes());
                        pressEnterToContinue("And was created by you.");
                        removeLines(3);
                    }
                    else {
                        out.write("\n\nTag with same ID already exists.\n".getBytes());
                        pressEnterToContinue("And was not created by you.");
                        removeLines(3);
                    }
                }
                else {
                    database.addTag(name, this.user.getName());
                    out.write(("\n\nTag \"" + name.replace('\n', ' ') + "\" didn't exist yet.\n").getBytes());
                    pressEnterToContinue("Tag added");
                    removeLines(3);
                }
            }
        }

        clearScreen();
        printWelcomeScreen();
    }

    private void importQuestions() throws IOException, SQLException {
        out.write("Please paste Questions data\n\n".getBytes());
        String base = getInput();
        //TODO IllegalArgumentException: Illegal base64 character
        String input = new String(Base64.getDecoder().decode(base.getBytes()));
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(input);
        } catch (JSONException e) {
            pressEnterToContinue("invalid data");
            clearScreen();
            printWelcomeScreen();
            return;
        }

        String key = jsonObject.keys().next();
        JSONArray questions = jsonObject.getJSONArray(key);

        for (int i = 0; i < questions.length(); i++) {
            JSONObject question = questions.getJSONObject(i);

            int id;
            String name;
            JSONArray answers;
            int correctAnswer;
            int tagId;
            String tagName;
            String creator;
            boolean isPublic;
            try {
                id = question.getInt("id");
                name = question.getString("name");
                answers = question.getJSONArray("answers");
                correctAnswer = question.getInt("correct_answer");
                tagId = question.getInt("tag_id");
                tagName = question.getString("tag_name");
                creator = question.getString("creator");
                isPublic = question.getBoolean("public");
            } catch (JSONException e) {
                pressEnterToContinue("invalid data");
                clearScreen();
                printWelcomeScreen();
                return;
            }

            PreparedStatement stmt = getQuestionOrTag(key, id);
            try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                if (resultSet.next()) {
                    String name1 = resultSet.getString("name");
                    if (creator.equals(this.user.getName())) {
                        out.write(("\n\nQuestion \"" + name1.replace('\n', ' ') + "\" already exists.\n").getBytes());
                        pressEnterToContinue("And was created by you.");
                        removeLines(3);
                    }
                    else {
                        out.write("\n\nQuestion with same ID already exists.\n".getBytes());
                        pressEnterToContinue("And was not created by you.");
                        removeLines(3);
                    }
                }
                else {
                    database.addQuestionWithID(id, name, answers.getString(0), answers.getString(1),
                            answers.getString(2), answers.getString(3), correctAnswer, tagName,
                            this.user.getName(), isPublic);
                    out.write(("\n\nQuestion \"" + name.replace('\n', ' ') + "\" didn't exist yet.\n").getBytes());
                    pressEnterToContinue("Question added");
                    removeLines(3);
                }
            }
        }

        clearScreen();
        printWelcomeScreen();
    }

    public void importTagsAndQuestions() throws IOException, SQLException {
        out.write("Please paste Tags and Questions data\n\n".getBytes());
        String base = getInput();
        String input = new String(Base64.getDecoder().decode(base.getBytes()));
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(input);
        } catch (JSONException e) {
            pressEnterToContinue("invalid data");
            clearScreen();
            printWelcomeScreen();
            return;
        }

        for (String key : jsonObject.keySet()) {
            JSONArray array = jsonObject.getJSONArray(key);

            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i);

                switch (key) {
                    case "tags":
                        int tagId;
                        String tagName;
                        String tagCreator;

                        try {
                            tagId = object.getInt("id");
                            tagName = object.getString("name");
                            tagCreator = object.getString("creator");
                        } catch (JSONException e) {
                            pressEnterToContinue("invalid data");
                            clearScreen();
                            printWelcomeScreen();
                            return;
                        }

                        PreparedStatement stmt = getQuestionOrTag(key, tagId);
                        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                            if (resultSet.next()) {
                                String creator = resultSet.getString("creator");
                                if (creator.equals(this.user.getName())) {
                                    out.write(("\n\nTag \"" + creator.replace('\n', ' ') + "\" already exists.\n").getBytes());
                                    pressEnterToContinue("And was created by you.");
                                    removeLines(3);
                                }
                                else {
                                    out.write("\n\nTag with same ID already exists.\n".getBytes());
                                    pressEnterToContinue("And was not created by you.");
                                    removeLines(3);
                                }
                            }
                            else {
                                database.addTag(tagName, this.user.getName());
                                out.write(("\n\nTag \"" + tagName.replace('\n', ' ') + "\" didn't exist yet.\n").getBytes());
                                pressEnterToContinue("Tag added");
                                removeLines(3);
                            }
                        }
                        break;
                    case "questions":
                        int questionId;
                        String questionName;
                        JSONArray questionAnswers;
                        int questionCorrectAnswer;
                        int questionTagId;
                        String questionTagName;
                        String questionCreator;
                        boolean questionIsPublic;
                        try {
                            questionId = object.getInt("id");
                            questionName = object.getString("name");
                            questionAnswers = object.getJSONArray("answers");
                            questionCorrectAnswer = object.getInt("correct_answer");
                            questionTagId = object.getInt("tag_id");
                            questionTagName = object.getString("tag_name");
                            questionCreator = object.getString("creator");
                            questionIsPublic = object.getBoolean("public");
                        } catch (JSONException e) {
                            pressEnterToContinue("invalid data");
                            clearScreen();
                            printWelcomeScreen();
                            return;
                        }

                        PreparedStatement stmt2 = getQuestionOrTag(key, questionId);
                        try (stmt2; ResultSet resultSet = stmt2.executeQuery()) {
                            if (resultSet.next()) {
                                String creator = resultSet.getString("creator");
                                if (creator.equals(this.user.getName())) {
                                    out.write(("\n\nQuestion \"" + questionName.replace('\n', ' ') + "\" already exists.\n").getBytes());
                                    pressEnterToContinue("And was created by you.");
                                    removeLines(3);
                                }
                                else {
                                    out.write("\n\nQuestion with same ID already exists.\n".getBytes());
                                    pressEnterToContinue("And was not created by you.");
                                    removeLines(3);
                                }
                            }
                            else {
                                database.addQuestionWithID(questionId, questionName, questionAnswers.getString(0),
                                        questionAnswers.getString(1), questionAnswers.getString(2),
                                        questionAnswers.getString(3), questionCorrectAnswer, questionTagName,
                                        this.user.getName(), questionIsPublic);
                                out.write(("\n\nQuestion \"" + questionName.replace('\n', ' ') + "\" didn't exist yet.\n").getBytes());
                                pressEnterToContinue("Question added");
                                removeLines(3);
                            }
                        }
                        break;
                }
            }
        }
        clearScreen();
        printWelcomeScreen();
    }

    private void listYourTagsAndQuestions() throws IOException, SQLException {
        Tag[] tags = database.getAllTagsFromuser(this.user.getName());
        Question[] questions = database.getAllQuestionsFromUser(this.user.getName());

        out.write("Your Tags:\n".getBytes());
        int i = 1;
        for (Tag tag : tags) {
            i++;
            out.write((tag.getName() + "\n").getBytes());
        }
        out.write("\nYour Questions:\n".getBytes());
        i += 2;
        for (Question question : questions) {
            i++;
            out.write((question.getName().replaceAll("\n", "") + "\n").getBytes());
        }
        out.write("\n".getBytes());
        i++;
        pressEnterToContinue("That are all your tags and questions.");
        removeLines(i);
    }

    private PreparedStatement getQuestionOrTag(String key, int id) throws IOException, SQLException {
        String sql;
        switch (key) {
            case "questions" -> sql = "SELECT name, creator FROM questions WHERE id = ?";
            case "tags" -> sql = "SELECT name, creator FROM tags WHERE id = ?";
            default -> {
                out.write("something went wrong\n".getBytes());
                throw new RuntimeException("Something went wrong");
            }
        }
        return database.prepareSanitizeQuery(sql, id);
    }

    private void registerUser() throws IOException, SQLException {
        out.write("Create new User\n".getBytes());
        out.write("Username: ".getBytes());
        String username = getInput();
        out.write("Password: ".getBytes());
        String password = getInput();
        removeLines(3);

        if (username.isEmpty() || password.isEmpty()) {
            pressEnterToContinue("Username or password cannot be empty.");
            return;
        }

        int value = database.addUser(username, password);
        if (value == -1) {
            pressEnterToContinue("User already exists.");
            return;
        }

        pressEnterToContinue("Created new User.");

        TimeZone timeZone = database.getUserTimeZone(username);

        long lastLoginTime = database.getUserLastLoginTime(username);

        user = new User(username, this, timeZone, lastLoginTime);
    }

    private void loginUser() throws IOException, SQLException {
        out.write("Username: ".getBytes());
        String username = getInput();
        out.write("Password: ".getBytes());
        String password = getInput();
        removeLines(2);

        boolean credentialsValid = database.validCredentials(username, password);
        //TODO check if user is in deactivatedUsers db and ask to activate account again
        if (credentialsValid) {
            TimeZone timeZone = database.getUserTimeZone(username);
            long lastLoginTime = database.getUserLastLoginTime(username);
            String time = calculateLastLoginTime(timeZone, lastLoginTime);

            user = new User(username, this, timeZone, lastLoginTime);

            setLastLoginTime();

            pressEnterToContinue("Logged in as " + username + ". Last login: " + time);
        }
        else {
            pressEnterToContinue("Credentials are not valid.");
        }
    }

    private String loggedOutActions() throws IOException {
        printLoggedOutScreen();
        String input = getInput();

        while (!(Objects.equals(input, "0") ||
                 Objects.equals(input, "1"))) {
            //System.out.println(input);
            removeLines(4);
            printLoggedOutScreen();

            input = getInput();
        }
        removeLines(4);
        return input;
    }

    private String loggedInActions() throws IOException {
        printLoggedInScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2") ||
                Objects.equals(input, "3") ||
                Objects.equals(input, "4"))) {
            //System.out.println(input);
            removeLines(7);
            printLoggedInScreen();

            input = getInput();
        }
        removeLines(7);
        return input;
    }

    private void openTargetedMatch() throws IOException, SQLException {
        String action = targetedMatchActions();
        switch(action) {
            case "0":
                continueMatchActions();
                break;
            case "1":
                viewOpenChallenges();
                break;
            case "2":
                createNewTargetedMatch();
                break;
            case "3":
                viewPastChallenges();
                break;
            case "4":
                break;
        }
    }

    private String targetedMatchActions() throws IOException {
        printTargetedMatchScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2") ||
                Objects.equals(input, "3") ||
                Objects.equals(input, "4"))) {
            //System.out.println(input);
            removeLines(7);
            printTargetedMatchScreen();

            input = getInput();
        }
        removeLines(7);
        return input;
    }

    public void printTargetedMatchScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Continue Match\n".getBytes());
        out.write("[1] View open Challenges\n".getBytes());
        out.write("[2] Create new targeted match\n".getBytes());
        out.write("[3] View past Challenges\n".getBytes());
        out.write("[4] Return\n".getBytes());
    }

    private String settingsActions() throws IOException {
        printSettingsScreen();
        String input = getInput();
        while (!(Objects.equals(input, "0") ||
                Objects.equals(input, "1") ||
                Objects.equals(input, "2"))) {
            //System.out.println(input);
            removeLines(4);
            printSettingsScreen();

            input = getInput();
        }
        removeLines(4);
        return input;
    }

    public void printSettingsScreen() throws IOException {
        out.write("[0] Set Status\n".getBytes());
        out.write("[1] Set Timezone\n".getBytes());
        out.write("[2] Return\n".getBytes());
    }

    public void continueMatchActions() throws IOException, SQLException {
        String username = user.getName();
        String sql = "SELECT * FROM runningTargetedMatches WHERE (challenger = ? and challenger_answer_correct IS NULL) or (target_player = ? and target_player_answer_correct IS NULL);";
        int matchID;
        boolean challenger_played;
        boolean target_played;
        int yourCounter = 0;
        HashMap<Integer, Integer> mapping = new HashMap<>();
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, username, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            out.write("Your turn:\n".getBytes());
            while (resultSet.next()) {
                matchID = resultSet.getInt("id");
                mapping.put(yourCounter, matchID);
                String challenger = resultSet.getString("challenger");
                String target_player = resultSet.getString("target_player");
                String opponent = challenger.equals(username) ? target_player : challenger;
                out.write(("[" + yourCounter + "] Match against " + opponent + "\n").getBytes());
                yourCounter++;
            }
            if (yourCounter == 0) {
                out.write("No matches\n".getBytes());
            }
        }

        sql = "SELECT * FROM runningTargetedMatches WHERE (challenger = ? and challenger_answer_correct IS NOT NULL) or (target_player = ? and target_player_answer_correct IS NOT NULL);";
        int opponentCounter = 0;
        out.write("Opponents turn:\n".getBytes());
        PreparedStatement stmt2 = database.prepareSanitizeQuery(sql, username, username);
        try (stmt2; ResultSet resultSet = stmt2.executeQuery()) {
            while (resultSet.next()) {
                String challenger = resultSet.getString("challenger");
                String target_player = resultSet.getString("target_player");
                String opponent = challenger.equals(username) ? target_player : challenger;
                out.write(("Match against " + opponent + "\n").getBytes());
                opponentCounter++;
            }
            if (opponentCounter == 0) {
                out.write("No matches\n".getBytes());
            }
        }

        int choice = selectTargetedMatch(yourCounter, opponentCounter);

        if (choice == -1) return;

        try {
            matchID = mapping.get(choice);
        } catch (NullPointerException e) {
            pressEnterToContinue("Not a valid match.");
            return;
        }

        String challenger;
        String target_player;
        int questionID;
        sql = "SELECT * FROM runningTargetedMatches WHERE id = ?;";
        PreparedStatement stmt3 = database.prepareSanitizeQuery(sql, matchID);
        try (stmt3; ResultSet resultSet = stmt3.executeQuery()) {
            challenger = resultSet.getString("challenger");
            target_player = resultSet.getString("target_player");

            questionID = resultSet.getInt("currentQuestionID");

            if (resultSet.wasNull()) {
                Question question = database.getRandomQuestion(challenger, target_player);
                questionID = question.getId();
                sql = "UPDATE runningTargetedMatches SET currentQuestionID = ? WHERE id = ?;";
                database.executeSanitizeUpdateQuery(sql, question.getId(), matchID);
            }
        }


        Question question = new Question(questionID);

        String opponent = challenger.equals(username) ? target_player : challenger;

        String opponent_status;
        sql = "SELECT * FROM users WHERE username = ?;";
        PreparedStatement stmt4 = database.prepareSanitizeQuery(sql, opponent);
        try (stmt4; ResultSet resultSet = stmt4.executeQuery()) {
            opponent_status = resultSet.getString("status");
        }

        boolean correct = askQuestion(question, opponent, opponent_status);

        if (user.getName().equals(challenger)) {
            sql = "UPDATE runningTargetedMatches SET challenger_answer_correct = '" + (correct ? "true" : "false") + "' WHERE id = ?;";
            database.executeSanitizeUpdateQuery(sql, matchID);
        } else if (user.getName().equals(target_player)) {
            sql = "UPDATE runningTargetedMatches SET target_player_answer_correct = '" + (correct ? "true" : "false") + "' WHERE id = ?;";
            database.executeSanitizeUpdateQuery(sql, matchID);
        }


        sql = "SELECT * FROM runningTargetedMatches WHERE id = ?;";
        PreparedStatement stmt5 = database.prepareSanitizeQuery(sql, matchID);
        try (stmt5; ResultSet resultSet = stmt5.executeQuery()) {
            challenger_played = resultSet.getString("challenger_answer_correct") != null;
            target_played = resultSet.getString("target_player_answer_correct") != null;
        }

        if (challenger_played && target_played) {
            targetedMatchNextRound(matchID);
        }
    }

    public void viewPastChallenges() throws IOException, SQLException {
        String username = user.getName();
        String sql = "SELECT * FROM finishedTargetedMatches WHERE (challenger = ?) or (target_player = ?);";
        int counter = 0;
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, username, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                String challenger = resultSet.getString("challenger");
                String target_player = resultSet.getString("target_player");
                int challenger_score = resultSet.getInt("challenger_score");
                int target_player_score = resultSet.getInt("target_player_score");
                int won;
                if (challenger.equals(username)) {
                    won = Integer.compare(challenger_score, target_player_score);
                }
                else {
                    won = Integer.compare(target_player_score, challenger_score);
                }
                String text = switch (won) {
                    case 0 ->  "DRAW     - ";
                    case -1 -> "YOU LOST - ";
                    case 1 ->  "YOU WON  - ";
                    default -> "         - ";
                };
                out.write((text +  challenger + " VS " + target_player + " Score: " + challenger_score + ":" + target_player_score + "\n").getBytes());
                counter++;
            }
            if (counter == 0) {
                out.write("No matches yet\n".getBytes());
            }
        }
        pressEnterToContinue("");
        removeLines(counter);
    }

    public void targetedMatchNextRound(int matchID) throws SQLException {
        String sql = "SELECT * FROM runningTargetedMatches WHERE id = ?;";
        int challenger_score;
        int target_player_score;
        String challenger_answer_correct;
        String target_player_answer_correct;
        int round;
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, matchID);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            challenger_score = resultSet.getInt("challenger_score");
            target_player_score = resultSet.getInt("target_player_score");
            challenger_answer_correct = resultSet.getString("challenger_answer_correct");
            target_player_answer_correct = resultSet.getString("target_player_answer_correct");
            round = resultSet.getInt("round");
        }

        if (challenger_answer_correct.equals("true") || challenger_answer_correct.equals("1")) {
            sql = "UPDATE runningTargetedMatches SET challenger_score = ? WHERE id = ?;";
            database.executeSanitizeUpdateQuery(sql, challenger_score + 1, matchID);
        }
        if (target_player_answer_correct.equals("true") || target_player_answer_correct.equals("1")) {
            sql = "UPDATE runningTargetedMatches SET target_player_score = ? WHERE id = ?;";
            database.executeSanitizeUpdateQuery(sql, target_player_score + 1, matchID);
        }

        sql = "UPDATE runningTargetedMatches SET challenger_answer_correct = NULL WHERE id = ?;";
        database.executeSanitizeUpdateQuery(sql, matchID);

        sql = "UPDATE runningTargetedMatches SET target_player_answer_correct = NULL WHERE id = ?;";
        database.executeSanitizeUpdateQuery(sql, matchID);

        sql = "UPDATE runningTargetedMatches SET currentquestionID = NULL WHERE id = ?;";
        database.executeSanitizeUpdateQuery(sql, matchID);

        if (round >= Main.ROUND_NUMBER) {
            finishTargetedMatch(matchID);
        }
        else {
            sql = "UPDATE runningTargetedMatches SET round = ? WHERE id = ?;";
            database.executeSanitizeUpdateQuery(sql, ++round, matchID);
        }
    }

    public void finishTargetedMatch(int matchID) throws SQLException {
        //System.out.println("MATCH FINISHED: " + matchID);
        String sql = "SELECT * FROM runningTargetedMatches WHERE id = ?;";
        String challenger;
        String target_player;
        int challenger_score;
        int target_player_score;
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, matchID);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            challenger = resultSet.getString("challenger");
            target_player = resultSet.getString("target_player");
            challenger_score = resultSet.getInt("challenger_score");
            target_player_score = resultSet.getInt("target_player_score");
        }

        Calendar timeCalendar = java.util.Calendar.getInstance();
        long currentTime = timeCalendar.getTime().getTime();

        sql = "INSERT INTO finishedTargetedMatches (id, challenger, target_player, challenger_score, target_player_score, creation_time) VALUES (?, ?, ?, ?, ?, ?);";
        database.executeSanitizeUpdateQuery(sql, matchID, challenger, target_player, challenger_score, target_player_score, currentTime);


        sql = "DELETE FROM runningTargetedMatches WHERE id = ?;";
        database.executeSanitizeUpdateQuery(sql, matchID);
    }

    public int selectTargetedMatch(int yourCounter, int opponentCounter) throws IOException {
        out.write("Which match do you want to continue? (leave empty to return) ".getBytes());
        String input = getInput();
        if (input.isEmpty()) {
            removeLines(yourCounter + opponentCounter + 4);
            return -1;
        }

        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            removeLines(yourCounter + opponentCounter + 4);
            pressEnterToContinue("Not a valid number.");
            return -1;
        }
        if (choice > yourCounter) {
            removeLines(yourCounter + opponentCounter + 4);
            pressEnterToContinue("Number is to big.");
            return -1;
        }
        removeLines(yourCounter + opponentCounter + 4);
        return choice;
    }

    public void viewOpenChallenges() throws IOException, SQLException {
        String username = user.getName();

        String sql = "SELECT * FROM openTargetedMatches WHERE challenger = ?;";
        String challenger;
        String target_player;
        long automatic_accept_time;
        String timeZone;
        int id;
        HashMap<Integer, Integer> mapping = new HashMap<>();
        out.write("You challenged:\n".getBytes());
        int counter = 0;
        int i = 0;
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, username);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            while (resultSet.next()) {
                int matchID = resultSet.getInt("id");
                mapping.put(counter, matchID);
                target_player = resultSet.getString("target_player");
                out.write(("[" + counter + "] You challenged " + target_player + "\n").getBytes());
                counter++;
                i++;
            }
            if (i == 0) {
                out.write("No challenges found.\n".getBytes());
            }
        }

        i = 0;
        out.write("Your challenges:\n".getBytes());
        sql = "SELECT * FROM openTargetedMatches WHERE target_player = ?;";
        PreparedStatement stmt2 = database.prepareSanitizeQuery(sql, username);
        try (stmt2; ResultSet resultSet = stmt2.executeQuery()) {
            while (resultSet.next()) {
                int matchID = resultSet.getInt("id");
                mapping.put(counter, matchID);
                challenger = resultSet.getString("challenger");
                out.write(("[" + counter + "] You got challenged by " + challenger + "\n").getBytes());
                counter++;
                i++;
            }
            if (i == 0) {
                out.write("No challenges found.\n".getBytes());
            }
        }

        int choice = selectTargetedMatchChallenge(counter);

        if (choice == -1) {
            return;
        }

        int matchID;
        try {
            matchID = mapping.get(choice);
        } catch (NullPointerException e) {
            pressEnterToContinue("Not a valid match.");
            return;
        }
        sql = "SELECT * FROM openTargetedMatches WHERE id = ?;";
        PreparedStatement stmt3 = database.prepareSanitizeQuery(sql, matchID);
        try (stmt3; ResultSet resultSet = stmt3.executeQuery()) {
            challenger = resultSet.getString("challenger");
            target_player = resultSet.getString("target_player");
            automatic_accept_time = resultSet.getLong("automatic_accept_time");
            timeZone = resultSet.getString("user_timezone");
            id = resultSet.getInt("id");
        }

        if (username.equals(challenger)) {
            String time = calculateTime(timeZone, automatic_accept_time);
            printTargetedMatchChallengerScreen(target_player, time);
            String input = getInput();
            while (!(Objects.equals(input, "0") ||
                    Objects.equals(input, "1"))) {
                removeLines(5);
                pressEnterToContinue("Not a valid number.");
                printTargetedMatchChallengerScreen(target_player, time);
                input = getInput();
            }
            removeLines(5);

            switch (input) {
                case "0":
                    sql = "DELETE FROM openTargetedMatches WHERE id = ?;";
                    database.executeSanitizeUpdateQuery(sql, id);
                    pressEnterToContinue("Deleted Challenge");
                    break;
                case "1":
                    break;
            }
        }

        else if (username.equals(target_player)) {
            String time = calculateTime(timeZone, automatic_accept_time);
            printTargetedMatchTargetPlayerScreen(target_player, time);
            String input = getInput();
            while (!(Objects.equals(input, "0") ||
                    Objects.equals(input, "1") ||
                    Objects.equals(input, "2"))) {
                removeLines(6);
                pressEnterToContinue("Not a valid number.");
                printTargetedMatchChallengerScreen(target_player, time);
                input = getInput();
            }
            removeLines(6);

            switch (input) {
                case "0":
                    Calendar timeCalendar = java.util.Calendar.getInstance();
                    long currentTime = timeCalendar.getTime().getTime();
                    sql = "INSERT INTO runningTargetedMatches (id, challenger, target_player, currentQuestionID, challenger_score, target_player_score, challenger_answer_correct, target_player_answer_correct, round, creation_time) VALUES (?, ?, ?, null, '0', '0', null, null, 1, ?);";
                    database.executeSanitizeUpdateQuery(sql, id, challenger, target_player, currentTime);
                    sql = "DELETE FROM openTargetedMatches WHERE id = ?;";
                    database.executeSanitizeUpdateQuery(sql, id);
                    pressEnterToContinue("Accepted Challenge");
                    break;
                case "1":
                    sql = "DELETE FROM openTargetedMatches WHERE id = ?;";
                    database.executeSanitizeUpdateQuery(sql, id);
                    pressEnterToContinue("Rejected Challenge");
                    break;
                case "2":
                    break;
            }
        }
    }

    public String calculateTime(String timeZone, long automatic_accept_time) {
        Calendar challengerTimeCalendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone(timeZone));
        challengerTimeCalendar.setTimeInMillis(automatic_accept_time);
        challengerTimeCalendar.setTimeZone(user.getTimeZone());
        return getTimeString(challengerTimeCalendar);
    }

    //TODO refactor to make 1 function
    public String calculateLastLoginTime(TimeZone timeZone, long time) {
        Calendar challengerTimeCalendar = java.util.Calendar.getInstance();
        challengerTimeCalendar.setTimeInMillis(time);
        challengerTimeCalendar.setTimeZone(timeZone);
        return getTimeString(challengerTimeCalendar);
    }

    private String getTimeString(Calendar challengerTimeCalendar) {
        String year = String.valueOf(challengerTimeCalendar.get(Calendar.YEAR));
        String month = String.valueOf(challengerTimeCalendar.get(Calendar.MONTH) + 1);
        String day = String.valueOf(challengerTimeCalendar.get(Calendar.DAY_OF_MONTH));
        String hour = String.valueOf(challengerTimeCalendar.get(Calendar.HOUR_OF_DAY));
        String minute = String.valueOf(challengerTimeCalendar.get(Calendar.MINUTE));
        String second = String.valueOf(challengerTimeCalendar.get(Calendar.SECOND));
        return hour + ":" + minute + ":" + second + " " + day + "." + month + "." + year;
    }

    public void printTargetedMatchChallengerScreen(String opponent, String autoAcceptTime) throws IOException {
        out.write(("You challenged " + opponent + "\n").getBytes());
        out.write(("Autoaccept at " + autoAcceptTime + "\n").getBytes());
        out.write("[0] Cancel Challenge\n".getBytes());
        out.write("[1] Return\n".getBytes());
    }

    public void printTargetedMatchTargetPlayerScreen(String opponent, String autoAcceptTime) throws IOException {
        out.write(("You got challenged by " + opponent + "\n").getBytes());
        out.write(("Autoaccept at " + autoAcceptTime + "\n").getBytes());
        out.write("[0] Accept\n".getBytes());
        out.write("[1] Deny\n".getBytes());
        out.write("[2] Return\n".getBytes());
    }

    public int selectTargetedMatchChallenge(int counter) throws IOException {
        out.write("Which challenge do you want to select? (leave empty to return) ".getBytes());
        String input = getInput();
        if (input.isEmpty()) {
            removeLines(counter + 4);
            return -1;
        }

        int choice;
        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            removeLines(counter + 4);
            pressEnterToContinue("Not a valid number.");
            return -1;
        }
        if (choice > counter) {
            removeLines(counter + 4);
            pressEnterToContinue("Number is to big.");
            return -1;
        }
        removeLines(counter + 4);
        return choice;
    }

    public void setCurrentMatch(Match match) {
        currentMatch = match;
    }

    private void createNewTargetedMatch() throws IOException, SQLException {
        out.write("Who do you want to challenge? (leave empty to return) ".getBytes());
        String target_username = getInput();
        while (!database.existsUser(target_username)) {
            removeLines(1);
            if (target_username.isEmpty()) {
                pressEnterToContinue("Match creation cancelled.");
                return;
            }
            pressEnterToContinue("Username does not exist.");
            out.write("Who do you want to challenge? (leave empty to return) ".getBytes());
            target_username = getInput();
        }
        removeLines(1);

        if (target_username.equals(user.getName())) {
            pressEnterToContinue("You cannot challenge yourself!");
            return;
        }

        Calendar calendar = java.util.Calendar.getInstance(user.getTimeZone());
        //you have 24h to accept a challenge
        calendar.add(Calendar.HOUR, 24);

        Calendar calendar_in_24_hours = new GregorianCalendar();
        calendar_in_24_hours.set(Calendar.YEAR, calendar.get(Calendar.YEAR));
        calendar_in_24_hours.set(Calendar.MONTH, calendar.get(Calendar.MONTH));
        calendar_in_24_hours.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
        calendar_in_24_hours.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY));
        calendar_in_24_hours.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE));
        calendar_in_24_hours.set(Calendar.SECOND, calendar.get(Calendar.SECOND));
        calendar_in_24_hours.set(Calendar.MILLISECOND, calendar.get(Calendar.MILLISECOND));

        database.addOpenTargetedMatch(user.getName(), target_username, calendar_in_24_hours.getTime().getTime(), user.getTimeZone().getID());

    }

    private void startNewMatch() throws InterruptedException, IOException, SQLException {
        Matchmaker matchmaker = Matchmaker.getInstance();
        matchmaker.addUserToQueue(this.user);

        //System.out.println(user.getName() + " joined queue");
        outerLoop:
        while (true) {
            while (signal == Signal.WAIT_FOR_MATCH) {
                try {
                    out.write(("Waiting for match, " + matchmaker.getUserCount() + " user waiting.\nPress Enter to cancel.\n").getBytes());
                    socket.setSoTimeout(1000);
                    byte[] input = new byte[512];

                    try {
                        in.read(input);
                    } catch (SocketTimeoutException e) {
                        // do nothing
                    }

                    removeLines(2);
                    socket.setSoTimeout(Main.SOCKET_TIMEOUT);
                    if (new String(input).contains("\n")) {
                        matchmaker.removeUserFromQueue(this.user);
                        removeLines(1);
                        break outerLoop;
                    }
                } catch (Exception e) {
                    matchmaker.removeUserFromQueue(this.user);
                    socket.close();
                    in.close();
                    out.close();
                    scanner.close();
                    throw e;
                }
            }
            while (signal == Signal.ANSWERED_QUESTION) {
                out.write("Please wait for opponent\n".getBytes());
                TimeUnit.MILLISECONDS.sleep(500);
                removeLines(1);
            }

            if (signal == Signal.NEW_QUESTION) {
                signal = Signal.EMPTY_SIGNAL;
                currentAnswerCorrect = askQuestion(currentMatch.currentQuestion, currentMatch.getOpponentName(this.user), database.getUserStatus(currentMatch.getOpponentName(this.user)));
                signal = Signal.ANSWERED_QUESTION;
            }
            if (signal == Signal.GAME_WON || signal == Signal.GAME_LOST || signal == Signal.GAME_DRAW) {
                finishMatch(currentMatch.getOwnScore(user), currentMatch.getOpponentScore(user));
            }
            if (signal == Signal.GAME_OVER) {
                signal = Signal.EMPTY_SIGNAL;
                currentMatch = null;
                break;
            }
            TimeUnit.SECONDS.sleep(1);
        }
        userLoggedIn();
    }


    public boolean askQuestion(Question question, String opponentName, String opponentStatus) throws IOException, SQLException {
        out.write(("Match against " + opponentName + "\n").getBytes());
        opponentStatus = (opponentStatus == null) ? "Nothing" : opponentStatus;
        if (opponentStatus != null && opponentStatus.contains("+++")) {
            opponentStatus = "";
        }

        out.write(("Opponent says: " + opponentStatus + "\n").getBytes());

        char choice;
        while (true) {
            out.write((question.getName()).getBytes());
            out.write(("Category: " + question.getTag_name() + "\n").getBytes());
            String[] answers = question.getAnswers();
            char letter = 'A';
            for (String answer : answers) {
                out.write(("[" + letter + "] " + answer).getBytes());
                letter++;
            }

            String input = getInput();

            removeLines(7);
            if (input.isEmpty()) {
                continue;
            }

            choice = input.toCharArray()[0];

            if (choice >= 'A' && choice < letter) {
                break;
            }
            else {
                pressEnterToContinue("Please input the answer as a capital letter.");
            }
        }
        removeLines(2);
        boolean correct = choice - 65 == question.getCorrect_answer();
        pressEnterToContinue(correct ? "Correct" : "Incorrect");
        return correct;
    }

    public boolean getCurrentAnswerCorrect() {
        return currentAnswerCorrect;
    }

    public void finishMatch(int ownScore, int opponentScore) throws IOException {
        if (signal == Signal.GAME_WON) {
            pressEnterToContinue("You Won!!!\tScore " + ownScore + ":" + opponentScore);
            signal = Signal.GAME_OVER;
        }
        else if (signal == Signal.GAME_DRAW) {
            pressEnterToContinue("Draw\tScore " + ownScore + ":" + opponentScore);
            signal = Signal.GAME_OVER;
        }
        else if (signal == Signal.GAME_LOST) {
            pressEnterToContinue("You Lost :(\tScore " + ownScore + ":" + opponentScore);
            signal = Signal.GAME_OVER;
        }
    }

    private void printWelcomeScreen() throws IOException {
        out.write("Welcome to Quiztraction!\n".getBytes());
    }

    private String getInput() throws IOException {
        String line = null;
        try {
            line =  scanner.nextLine();
        } catch (NoSuchElementException e) {
            String username = user == null ? "User" : user.getName();
            //System.out.println(username + " disconnected");
            socket.close();
            in.close();
            out.close();
            scanner.close();
        }
        //TODO handle a disconnect
        return line;
    }

    private void printLoggedOutScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Register\n".getBytes());
        out.write("[1] Login\n".getBytes());
    }

    private void printLoggedInScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Play new live Match\n".getBytes());
        out.write("[1] Open targeted Match Menu\n".getBytes());
        out.write("[2] Manage Questions and Tags\n".getBytes());
        out.write("[3] Settings\n".getBytes());
        out.write("[4] Logout\n".getBytes());
    }

    private void printManageQuestionsScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Open Add Menu\n".getBytes());
        out.write("[1] Open Import Menu\n".getBytes());
        out.write("[2] Open Export Menu\n".getBytes());
        out.write("[3] Open Delete Menu\n".getBytes());
        out.write("[4] List your Tags and Questions\n".getBytes());
        out.write("[5] Return\n".getBytes());
    }

    private void printExportScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Export Tags\n".getBytes());
        out.write("[1] Export Questions\n".getBytes());
        out.write("[2] Export Tags and Questions\n".getBytes());
        out.write("[3] Return\n".getBytes());
    }

    private void printImportScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Import Tags\n".getBytes());
        out.write("[1] Import Questions\n".getBytes());
        out.write("[2] Import Tags and Questions\n".getBytes());
        out.write("[3] Return\n".getBytes());
    }

    private void printDeleteScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Delete unused Tags\n".getBytes());
        out.write("[1] Delete Questions\n".getBytes());
        out.write("[2] Return\n".getBytes());
    }

    private void printAddScreen() throws IOException {
        out.write("What do you want to do?\n".getBytes());
        out.write("[0] Add Tag\n".getBytes());
        out.write("[1] Add Question\n".getBytes());
        out.write("[2] Return\n".getBytes());
    }

    private void removeLines(int count) throws IOException {
        for (int i = 0; i < count; i++) {
            out.write("\033[1A".getBytes());
        }

        for (int i = 0; i < count; i++) {
            out.write("\033[2K\n".getBytes());
        }

        for (int i = 0; i < count; i++) {
            out.write("\033[1A".getBytes());
        }
    }

    private void clearScreen() throws IOException {
        out.write("\033[H\033[2J".getBytes());
    }

    private void pressEnterToContinue(String message) throws IOException {
        if (!message.endsWith("\n")) message += "\n";
        out.write(message.getBytes());
        out.write("Press ENTER to continue\n".getBytes());
        getInput();
        removeLines(3);
    }
}
