package org.Quiztraction;

import org.Quiztraction.Connection.Connection;

import java.util.TimeZone;

public class User {
    String name;
    public Connection connection;
    TimeZone timeZone;
    long lastLoginTime;

    public User(String name, Connection connection, TimeZone timeZone, long lastLoginTime) {
        this.name = name;
        this.connection = connection;
        this.timeZone = timeZone;
        this.lastLoginTime = lastLoginTime;
    }

    public String getName() {
        return name;
    }

    public TimeZone getTimeZone() {return timeZone;}

    public void setTimeZone(TimeZone timeZone) {this.timeZone = timeZone;}

    public void setLastLoginTime(long lastLoginTime) {this.lastLoginTime = lastLoginTime;}
}
