package org.Quiztraction;

import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Question {
    private String name;
    private String[] answers;
    int correctAnswer;
    static DatabaseWrapper database;
    int questionID = -1;
    int tag_id;
    String creator;
    boolean poblic;

    public Question(int questionID, String question, String[] answers, int correctAnswer) {
        this.questionID = questionID;
        if (question.endsWith("\n")) this.name = question;
        else this.name = question + "\n";

        this.answers = new String[] {
                answers[0].endsWith("\n") ? answers[0] : answers[0] + "\n",
                answers[1].endsWith("\n") ? answers[1] : answers[1] + "\n",
                answers[2].endsWith("\n") ? answers[2] : answers[2] + "\n",
                answers[3].endsWith("\n") ? answers[3] : answers[3] + "\n",
        };

        this.correctAnswer = correctAnswer;
    }

    public Question(int questionID) throws SQLException {
        if (database == null) database = DatabaseWrapper.getInstance();
        String sql = "SELECT * FROM questions WHERE id = ?";
        String question;
        String answer0;
        String answer1;
        String answer2;
        String answer3;
        int correctAnswer;
        int tag_id;
        String creator;
        boolean poblic;
        PreparedStatement stmt = database.prepareSanitizeQuery(sql, questionID);
        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
            question = resultSet.getString("name");
            answer0 = resultSet.getString("answer0");
            answer1 = resultSet.getString("answer1");
            answer2 = resultSet.getString("answer2");
            answer3 = resultSet.getString("answer3");
            correctAnswer = resultSet.getInt("correct_answer");
            tag_id = resultSet.getInt("tag_id");
            creator = resultSet.getString("creator");
            poblic = resultSet.getBoolean("public");
        }

        if (question.endsWith("\n")) this.name = question;
        else this.name = question + "\n";

        this.answers = new String[] {
                answer0.endsWith("\n") ? answer0 : answer0 + "\n",
                answer1.endsWith("\n") ? answer1 : answer1 + "\n",
                answer2.endsWith("\n") ? answer2 : answer2 + "\n",
                answer3.endsWith("\n") ? answer3 : answer3 + "\n",
        };

        this.correctAnswer = correctAnswer;
        this.questionID = questionID;
        this.tag_id = tag_id;
        this.creator = creator;
        this.poblic = poblic;
    }

    public int getId() {
        return this.questionID;
    }

    public String getName() {
        return this.name;
    }

    public String[] getAnswers() {
        return this.answers;
    }

    public int getCorrect_answer() {
        return this.correctAnswer;
    }

    public int getTag_id() {return this.tag_id;}

    public String getTag_name() throws SQLException {
        return database.getTagName(this.tag_id);
    }

    public String getCreator() {return this.creator;}

    public boolean isPublic() {return this.poblic;}

}
