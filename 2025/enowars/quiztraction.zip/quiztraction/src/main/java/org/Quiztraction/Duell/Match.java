package org.Quiztraction.Duell;

import org.Quiztraction.Connection.Connection;
import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;
import org.Quiztraction.Question;
import org.Quiztraction.User;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

public class Match extends Thread {
    int matchID;
    User user1, user2;
    int user1Score, user2Score;
    int round;
    public Question currentQuestion;

    public Match(User user1, User user2) {
        matchID = getnewMatchID();
        this.user1 = user1;
        this.user2 = user2;
        user1Score = 0;
        user2Score = 0;
        round = 0;
    }

    @Override
    public void run() {
        final int MAX_ROUNDS = 3;
        for (int i = 0; i < MAX_ROUNDS; i++) {
            try {
                getNewRandomQuestion();
                sendQuestions();
                while (user1.connection.getSignal() != Connection.Signal.ANSWERED_QUESTION ||
                       user2.connection.getSignal() != Connection.Signal.ANSWERED_QUESTION) {
                    TimeUnit.SECONDS.sleep(1);
                }
                calculatePoints();
            } catch (IOException | InterruptedException | SQLException e) {
                throw new RuntimeException(e);
            }
        }
        finishMatch();
    }

    public void sendQuestions() throws IOException {
        user1.connection.setSignal(Connection.Signal.NEW_QUESTION);
        user2.connection.setSignal(Connection.Signal.NEW_QUESTION);
    }

    public void calculatePoints() {
        boolean user1Result = user1.connection.getCurrentAnswerCorrect();
        boolean user2Result = user2.connection.getCurrentAnswerCorrect();

        if (user1Result) user1Score++;
        if (user2Result) user2Score++;
        //System.out.println("Score: " + user1Score + " : " + user2Score);
    }

    private void finishMatch() {
        if (user1Score == user2Score) {
            user1.connection.setSignal(Connection.Signal.GAME_DRAW);
            user2.connection.setSignal(Connection.Signal.GAME_DRAW);
        }
        else if (user1Score > user2Score) {
            user1.connection.setSignal(Connection.Signal.GAME_WON);
            user2.connection.setSignal(Connection.Signal.GAME_LOST);
        }
        else if (user1Score < user2Score) {
            user1.connection.setSignal(Connection.Signal.GAME_LOST);
            user2.connection.setSignal(Connection.Signal.GAME_WON);
        }
    }

    public int getOwnScore(User user) {
        if (user.equals(user1)) return user1Score;
        if (user.equals(user2)) return user2Score;
        throw new RuntimeException("Invalid user");
    }

    public int getOpponentScore(User user) {
        if (user.equals(user1)) return user2Score;
        if (user.equals(user2)) return user1Score;
        throw new RuntimeException("Invalid user");
    }

    public String getOpponentName(User user) {
        if (user.equals(user1)) return user2.getName();
        else if (user.equals(user2)) return user1.getName();
        return "invalid username";
    }

    private int getnewMatchID() {
        return 1;
    }

    private void getNewRandomQuestion() throws SQLException {
        DatabaseWrapper databaseWrapper = DatabaseWrapper.getInstance();
        this.currentQuestion = databaseWrapper.getRandomQuestion(this.user1.getName(), this.user2.getName());
    }
}
