<template>
  <HelloWorld />
</template>

<script lang="ts" setup>
  //
</script>
