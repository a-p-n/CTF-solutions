package org.Quiztraction;

import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class Cleanup {

    static Cleanup instance;
    static DatabaseWrapper database;

    public static Cleanup getInstance() throws SQLException {
        if (instance == null) instance = new Cleanup();
        return instance;
    }

    private Cleanup() throws SQLException {
        database = DatabaseWrapper.getInstance();

        Thread cleanupThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    Calendar timeCalendar = java.util.Calendar.getInstance();
                    timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_INACTIVE_ACCOUNTS_AFTER_SECONDS);
                    long autodeactivateTime = timeCalendar.getTime().getTime();
                    try {
                        String sql = "SELECT * FROM users WHERE lastLogin < ?;";
                        PreparedStatement stmt = database.prepareSanitizeQuery(sql, autodeactivateTime);
                        try (stmt; ResultSet resultSet = stmt.executeQuery()) {
                            while (resultSet.next()) {
                                String username = resultSet.getString("username");
                                String password = resultSet.getString("password");
                                String timeZone = resultSet.getString("timeZone");
                                String status = resultSet.getString("status");
                                long lastLogin = resultSet.getLong("lastLogin");

                                String sqlCountUser = "SELECT COUNT(*) FROM deactivatedUsers WHERE username = ?";
                                int count;
                                PreparedStatement stmt2 = database.prepareSanitizeQuery(sqlCountUser, username);
                                try (stmt2; ResultSet resultSetCountUser = stmt2.executeQuery()) {
                                    count = resultSetCountUser.getInt(1);
                                }
                                boolean existsUser = count >= 1;

                                if (!existsUser) {
                                    sql = "INSERT INTO deactivatedUsers (username, password, timeZone, status, lastLogin) VALUES (?, ?, ?, ?, ?)";
                                    database.executeSanitizeUpdateQuery(sql, username, password, timeZone, status, lastLogin);
                                }
                                //TODO what to do if a deactivated Account has the same name?

                                //TODO remove tags and questions of deactivated accounts

                                //TODO terminate connection to user if user is logged in

                                sql = "DELETE FROM users WHERE username = ?";
                                database.executeSanitizeUpdateQuery(sql, username);
                            }
                        }


                        timeCalendar = java.util.Calendar.getInstance();
                        timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_INACTIVE_TAGS_AFTER_SECONDS);
                        autodeactivateTime = timeCalendar.getTime().getTime();

                        sql = "DELETE FROM tags WHERE creation_time < ? AND id NOT IN (SELECT DISTINCT tag_id FROM questions WHERE tag_id IS NOT NULL);";
                        try (PreparedStatement stmtTag = database.prepareSanitizeQuery(sql, autodeactivateTime)) {
                            stmtTag.executeUpdate();
                        }


                        timeCalendar = java.util.Calendar.getInstance();
                        timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_INACTIVE_DEACTIVATED_ACCOUNTS_AFTER_SECONDS);
                        autodeactivateTime = timeCalendar.getTime().getTime();

                        sql = "DELETE FROM deactivatedUsers WHERE lastLogin < ?;";
                        try (PreparedStatement stmtInactiveDeactivated = database.prepareSanitizeQuery(sql, autodeactivateTime)) {
                            stmtInactiveDeactivated.executeUpdate();
                        }


                        timeCalendar = java.util.Calendar.getInstance();
                        timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_QUESTIONS_AFTER_SECONDS);
                        autodeactivateTime = timeCalendar.getTime().getTime();

                        sql = "DELETE FROM questions WHERE creator IS NOT '' AND creation_time < ?;";
                        try (PreparedStatement stmtQuestions = database.prepareSanitizeQuery(sql, autodeactivateTime)) {
                            stmtQuestions.executeUpdate();
                        }

                        timeCalendar = java.util.Calendar.getInstance();
                        timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_FINISHED_TARGETED_MATCH_AFTER_SECONDS);
                        autodeactivateTime = timeCalendar.getTime().getTime();

                        sql = "DELETE FROM finishedTargetedMatches WHERE creation_time < ?;";
                        try (PreparedStatement stmtQuestions = database.prepareSanitizeQuery(sql, autodeactivateTime)) {
                            stmtQuestions.executeUpdate();
                        }

                        timeCalendar = java.util.Calendar.getInstance();
                        timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_RUNNING_TARGETED_MATCH_AFTER_SECONDS);
                        autodeactivateTime = timeCalendar.getTime().getTime();

                        sql = "DELETE FROM runningTargetedMatches WHERE creation_time < ?;";
                        try (PreparedStatement stmtRunning = database.prepareSanitizeQuery(sql, autodeactivateTime)) {
                            stmtRunning.executeUpdate();
                        }

                        timeCalendar = java.util.Calendar.getInstance();
                        timeCalendar.add(Calendar.SECOND, -Main.DEACTIVATE_OPEN_TARGETED_MATCH_AFTER_SECONDS);
                        autodeactivateTime = timeCalendar.getTime().getTime();

                        sql = "DELETE FROM openTargetedMatches WHERE creation_time < ?;";
                        try (PreparedStatement stmtOpen = database.prepareSanitizeQuery(sql, autodeactivateTime)) {
                            stmtOpen.executeUpdate();
                        }

                        TimeUnit.SECONDS.sleep(60);
                    } catch (InterruptedException | SQLException e) {
                        try {
                            System.err.println("Restarting Cleanup.");
                            System.err.println(e);
                            instance = new Cleanup();
                            Main.updateCleanup();
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                        throw new RuntimeException(e);
                    }
                }
            }
        });
        cleanupThread.start();
    }
}
