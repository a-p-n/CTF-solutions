#!/bin/bash

python3 tar.py