package org.Quiztraction;


import org.Quiztraction.Connection.Connection;
import org.Quiztraction.DatabaseWrapper.DatabaseWrapper;
import org.Quiztraction.Duell.Matchmaker;
import org.Quiztraction.Duell.TargetedMatchmaker;

import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;

public class Main {
    public static final int ROUND_NUMBER = 3;
    public static final int SOCKET_TIMEOUT = 60000;
    public static final int DEACTIVATE_INACTIVE_ACCOUNTS_AFTER_SECONDS = 1200;
    public static final int DEACTIVATE_INACTIVE_DEACTIVATED_ACCOUNTS_AFTER_SECONDS = 2400;
    public static final int DEACTIVATE_INACTIVE_TAGS_AFTER_SECONDS = 1200;
    public static final int DEACTIVATE_QUESTIONS_AFTER_SECONDS = 1200;
    public static final int DEACTIVATE_FINISHED_TARGETED_MATCH_AFTER_SECONDS = 1200;
    public static final int DEACTIVATE_RUNNING_TARGETED_MATCH_AFTER_SECONDS = 1200;
    public static final int DEACTIVATE_OPEN_TARGETED_MATCH_AFTER_SECONDS = 1200;
    static Matchmaker matchmaker = null;
    static TargetedMatchmaker targetedMatchmaker = null;
    static Cleanup cleanup = null;
    public static void main(String[] args) throws Exception {
        ServerSocket serverSocket = new ServerSocket(4242);

        DatabaseWrapper databaseWrapper = DatabaseWrapper.getInstance();

        matchmaker = Matchmaker.getInstance();
        targetedMatchmaker = TargetedMatchmaker.getInstance();
        cleanup = Cleanup.getInstance();


        while (true) {
            Socket socket = serverSocket.accept();
            socket.setSoTimeout(SOCKET_TIMEOUT);

            Runnable connectionHandler = new Connection(socket);
            new Thread(connectionHandler).start();

        }
    }

    public static void updateMatchmaker() {
        matchmaker = Matchmaker.getInstance();
    }

    public static void updateTargetedMatchmaker() throws SQLException {
        targetedMatchmaker = TargetedMatchmaker.getInstance();
    }

    public static void updateCleanup() throws SQLException {
        cleanup = Cleanup.getInstance();
    }

}